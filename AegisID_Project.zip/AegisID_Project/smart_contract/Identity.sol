pragma solidity ^0.8.0;

contract Identity {

    mapping(address => string) public users;

    function register(string memory hash) public {
        users[msg.sender] = hash;
    }

    function verify(address user)
        public
        view
        returns (string memory)
    {
        return users[user];
    }
}