# AegisID

AI-Driven Blockchain-Based Secure Digital Identity System

## Features
- Face Recognition
- Fingerprint Verification
- Voice Authentication
- Liveness Detection
- Blockchain Verification
- Adaptive MFA

## Technologies
- React.js
- Flask
- Python
- Ethereum
- Solidity
- MongoDB

## Run Backend
cd backend
pip install -r requirements.txt
python app.py

## Run Frontend
cd frontend
npm install
npm start