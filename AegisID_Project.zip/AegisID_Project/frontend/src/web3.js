export const connectWallet = async () => {
  console.log("MetaMask Connected");
};