import React, { useState } from "react";

function Login() {

  const [user, setUser] = useState("");

  const handleLogin = async () => {

    const formData = new FormData();
    formData.append("user_id", user);

    const response = await fetch(
      "http://127.0.0.1:5000/login",
      {
        method: "POST",
        body: formData
      }
    );

    const data = await response.json();
    alert(data.status);
  };

  return (
    <div style={{ textAlign: "center", marginTop: "100px" }}>
      <h1>AegisID</h1>

      <input
        type="text"
        placeholder="Enter User ID"
        onChange={(e) => setUser(e.target.value)}
      />

      <br /><br />

      <button onClick={handleLogin}>
        Login
      </button>
    </div>
  );
}

export default Login;