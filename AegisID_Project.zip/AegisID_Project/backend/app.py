from flask import Flask, request, jsonify
from flask_cors import CORS
from auth.face import verify_face_live
from auth.voice import verify_voice_live
from auth.fingerprint import verify_fingerprint
from auth.liveness import challenge_response
from auth.risk import calculate_risk
from blockchain.web3_service import verify_hash
from utils.hash import generate_hash

app = Flask(__name__)
CORS(app)

@app.route('/')
def home():
    return jsonify({"status": "AegisID Backend Running"})

@app.route('/register', methods=['POST'])
def register():
    user_id = request.form['user_id']
    data_hash = generate_hash(user_id)
    return jsonify({
        "status": "User Registered Successfully",
        "hash": data_hash
    })

@app.route('/login', methods=['POST'])
def login():
    if not verify_face_live():
        return jsonify({"status": "Face Authentication Failed"})

    if not verify_fingerprint("stored_fp.png", "input_fp.png"):
        return jsonify({"status": "Fingerprint Verification Failed"})

    risk = calculate_risk("user")

    if risk == "HIGH":
        if not verify_voice_live():
            return jsonify({"status": "Voice Authentication Failed"})

        if not challenge_response():
            return jsonify({"status": "Liveness Detection Failed"})

    blockchain_result = verify_hash()

    return jsonify({
        "status": "Access Granted",
        "blockchain": blockchain_result
    })

if __name__ == '__main__':
    app.run(debug=True)