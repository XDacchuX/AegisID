def verify_hash():
    return "Blockchain Verified"