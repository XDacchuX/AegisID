def challenge_response():
    return True