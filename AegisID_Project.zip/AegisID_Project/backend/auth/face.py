def verify_face_live(save=False):
    return True