def verify_voice_live(save=False):
    return True