import cv2

def verify_fingerprint(stored_img, input_img):
    fp1 = cv2.imread(stored_img, 0)
    fp2 = cv2.imread(input_img, 0)

    if fp1 is None or fp2 is None:
        return False

    fp1 = cv2.resize(fp1, (300, 300))
    fp2 = cv2.resize(fp2, (300, 300))

    difference = cv2.absdiff(fp1, fp2)
    score = difference.mean()

    return score < 25