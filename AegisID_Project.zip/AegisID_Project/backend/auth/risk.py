import datetime

def calculate_risk(user_id):
    hour = datetime.datetime.now().hour
    if hour < 6 or hour > 22:
        return "HIGH"
    return "LOW"